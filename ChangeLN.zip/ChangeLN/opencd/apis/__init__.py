# Copyright (c) Open-CD. All rights reserved.
from .opencd_inferencer import OpenCDInferencer

__all__ = ['OpenCDInferencer']