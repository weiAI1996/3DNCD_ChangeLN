_base_ = [
    '../_base_/models/fc_siam_conc.py',
    '../common/standard_256x256_40k_levircd.py']