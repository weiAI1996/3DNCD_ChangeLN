_base_ = [
    '../_base_/models/snunet_c16.py',
    '../common/standard_256x256_40k_levircd.py']