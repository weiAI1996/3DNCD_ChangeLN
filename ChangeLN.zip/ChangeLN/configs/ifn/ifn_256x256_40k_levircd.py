_base_ = [
    '../_base_/models/ifn.py', 
    '../common/standard_256x256_40k_levircd.py']
