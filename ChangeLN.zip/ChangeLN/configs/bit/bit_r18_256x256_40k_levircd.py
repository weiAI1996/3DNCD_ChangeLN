_base_ = [
    '../_base_/models/bit_r18.py', 
    '../common/standard_256x256_40k_levircd.py']
